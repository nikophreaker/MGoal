package com.providoindodigital.mgoal.data

class Match(
    var match: List<MatchData> = emptyList()
)