package com.providoindodigital.mgoal.funmatch

interface MatchsItemActionListener {
    fun onMatchClicked()
}