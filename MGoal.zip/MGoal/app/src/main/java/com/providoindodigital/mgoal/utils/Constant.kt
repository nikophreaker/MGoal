package com.providoindodigital.mgoal.utils

object Constant {
//    val BASE_URL = "https://mgoalindo.com/match2/"
//    val api_key = "1639"
    val BASE_URL = "http://api.isportsapi.com/sport/football/"
    val api_key = "24ZDsnqqFiLdkMv5"
}