package com.providoindodigital.mgoal.data

class ExtraExplain (
    var awayScore: Int? = 0,
    var extraAwayScore: Int? = 0,
    var extraHomeScore: Int? = 0,
    var extraTimeStatus: Int? = 0,
    var homeScore: Int? = 0,
    var kickOff: Int? = 0,
    var minute: Int? = 0,
    var penAwayScore: Int? = 0,
    var penHomeScore: Int? = 0,
    var twoRoundsAwayScore: Int? = 0,
    var twoRoundsHomeScore: Int? = 0,
    var winner: Int? = 0
)